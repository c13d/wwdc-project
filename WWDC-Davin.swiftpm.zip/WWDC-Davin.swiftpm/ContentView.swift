import SwiftUI


struct ContentView: View {
    
    @State private var item1Price = ""
    @State private var item1Size = ""
    @State private var item1SizeIndex = 0
    @State private var item1DiscountType = 0
    @State private var item1DiscountValue = ""
    @State private var item1Get = ""
    @State private var item1Unit = "pcs"
    
    @State private var item2Price = ""
    @State private var item2Size = ""
    @State private var item2SizeIndex = 0
    @State private var item2DiscountType = 0
    @State private var item2DiscountValue = ""
    @State private var item2Get = ""
    @State private var item2Unit = "pcs"
    
    @State var isCompareClicked = false
    
    @State private var cheaperItem = ""
    @State private var pricePerUnitItem1 = ""
    @State private var pricePerUnitItem2 = ""
    @State private var yousave = ""
    
    @State private var pricePerUnit2Item1 = ""
    @State private var pricePerUnit2Item2 = ""
    @State private var yousave2 = ""
    
    @State private var showingAlert = false

    
    let sizeOptions = ["pcs","mL","mg","L","g"]
    let discountTypes = ["%", "Buy X Get Y", "Buy X Get Y Free"]
    
    var body: some View {
        NavigationView{
            
            VStack {
                if #available(iOS 16.0, *) {
                    HStack{
                        
                    }
                    .navigationTitle("Price Detective").background(Color.white)
                    .toolbarBackground(Color.white, for: .navigationBar)
                    .toolbarBackground(.visible, for: .navigationBar)
                    .onTapGesture {
                        UIApplication.shared.endEditing()
                    }
                } else {
                    // Fallback on earlier versions
                    HStack{
                        
                    }
                    .navigationTitle("Price Detective").background(Color.white)
                    .onTapGesture {
                        UIApplication.shared.endEditing()
                    }
                }
                
                Spacer().frame(height: 16)
                HStack {
                    Spacer()
                    ItemCard(name: "Item 1", price: $item1Price, size: $item1Size, sizeIndex: $item1SizeIndex, discountType: $item1DiscountType, discountValue: $item1DiscountValue, get: $item1Get, unit: $item1Unit, sizeOptions: sizeOptions, discountTypes: discountTypes)
                    ItemCard(name: "Item 2", price: $item2Price, size: $item2Size, sizeIndex: $item2SizeIndex, discountType: $item2DiscountType, discountValue: $item2DiscountValue, get: $item2Get, unit: $item2Unit, sizeOptions: sizeOptions, discountTypes: discountTypes)
                    Spacer()
                }
                
                

                
                Spacer().frame(height: 18).onTapGesture {
                    UIApplication.shared.endEditing()
                }
                Button(action: {
                    self.comparePrices()
                    self.isCompareClicked = true
                    UIApplication.shared.endEditing()
                }) {
                    Text("Compare")
                        .foregroundColor(.white)
                        .padding(.vertical, 8)
                        .padding(.horizontal, 16)
                        .background(Color.blue)
                        .clipShape(Capsule())
                }
                .alert(isPresented: $showingAlert) {
                    Alert(
                        title: Text("Error"),
                        message: Text("\(item1Unit) and \(item2Unit) are not comparable units."),
                        dismissButton: .default(Text("OK"))
                    )
                }
                
                if !pricePerUnitItem1.isEmpty{
//                    Spacer().frame(height: 16)
//                    Text(cheaperItem).bold()
//                    Spacer().frame(height: 16)
                    Form{
                        Section(header: Text("Price per (\(item1Unit))")){
                            HStack {
                                Text("Item 1")
                                    .frame(maxWidth: .infinity, alignment:.leading)
                                Text(pricePerUnitItem1)
                                    .frame(maxWidth: .infinity, alignment: .trailing)
                            }
                            HStack {
                                Text("Item 2")
                                    .frame(maxWidth: .infinity, alignment:.leading)
                                Text(pricePerUnitItem2)
                                    .frame(maxWidth: .infinity, alignment: .trailing)
                            }
                            
                            if yousave != "" {
                                Text(yousave).bold()
                            }
                            
                        }
                        
                        if !pricePerUnit2Item1.isEmpty{
                            Section(header: Text("Price per (\(item2Unit))")){
                                HStack {
                                    Text("Item 1")
                                        .frame(maxWidth: .infinity, alignment:.leading)
                                    Text(pricePerUnit2Item1)
                                        .frame(maxWidth: .infinity, alignment: .trailing)
                                }
                                HStack {
                                    Text("Item 2")
                                        .frame(maxWidth: .infinity, alignment:.leading)
                                    Text(pricePerUnit2Item2)
                                        .frame(maxWidth: .infinity, alignment: .trailing)
                                }
                                
                                if yousave2 != "" {
                                    Text(yousave2).bold()
                                }
                                
                            }
                        }
                    }.onTapGesture {
                        UIApplication.shared.endEditing()
                    }
                }

                
                
//                .onChange(of: item1Unit){ newValue in
//                    comparePrices()
//                }
//
//                .onChange(of: item2Unit){ newValue in
//                    comparePrices()
//                }

//                if !pricePerUnitItem1.isEmpty{
//                    Spacer().frame(height: 16)
//                    Text(cheaperItem).bold()
//                    Spacer().frame(height: 16)
//                    Text("Price per (\(item1Unit))")
//
//                    HStack{
//                        Spacer()
//                        Text("Item 1").frame(width: UIScreen.main.bounds.width/2, alignment: .center)
//                        Text(pricePerUnitItem1).frame(width: UIScreen.main.bounds.width/2,alignment: .center)
//                        Spacer()
//                    }
//                    HStack{
//                        Spacer()
//                        Text("Item 2").frame(width: UIScreen.main.bounds.width/2, alignment: .center)
//                        Text(pricePerUnitItem2).frame(width: UIScreen.main.bounds.width/2,alignment: .center)
//                        Spacer()
//                    }
//                    Text(yousave)
//                    if !pricePerUnit2Item1.isEmpty{
//                        Spacer().frame(height: 32)
//
//                        Text("Price/(\(item2Unit))")
//                        HStack{
//                            Spacer()
//                            Text("Item 1").frame(width: UIScreen.main.bounds.width/2, alignment: .center)
//                            Text(pricePerUnit2Item1).frame(width: UIScreen.main.bounds.width/2,alignment: .center)
//                            Spacer()
//                        }
//                        HStack{
//                            Spacer()
//                            Text("Item 2").frame(width: UIScreen.main.bounds.width/2, alignment: .center)
//                            Text(pricePerUnit2Item2).frame(width: UIScreen.main.bounds.width/2,alignment: .center)
//                            Spacer()
//                        }
//                        Text(yousave2)
//                    }
//                    Spacer()
//                }

                Spacer()
                
            }
            .background(Color(UIColor(red: 242/255, green: 242/255, blue: 247/255, alpha: 1)))
                .onTapGesture {
//                    UIApplication.shared.endEditing()
                }
        }
    }
    
    func comparePrices(){
        if  (item1Unit == "pcs" && item2Unit != "pcs") ||
            (item2Unit == "pcs" && item1Unit != "pcs"){
            self.showingAlert = true
            return
        }else{
            self.showingAlert = false
        }

        guard let item1Price = Double(item1Price),
              let item1Size = Double(item1Size),
              let item2Price = Double(item2Price),
              let item2Size = Double(item2Size)
        else {
            cheaperItem = ""
            pricePerUnitItem1 = ""
            pricePerUnit2Item1 = ""
            return
        }
        
        
        var item1Unit = 1.0
        var item2Unit = 1.0
        
        if self.item1Unit == "mL" || self.item1Unit == "mg"{
            item1Unit = sizeUnitMilli(unit: self.item1Unit)
            item2Unit = sizeUnitMilli(unit: self.item2Unit)
        }else if self.item1Unit == "L" || self.item1Unit == "g"{
            item1Unit = sizeUnitL(unit: self.item1Unit)
            item2Unit = sizeUnitL(unit: self.item2Unit)
        }
    
        var item1PricePerUnit = item1Price/item1Unit/item1Size
        var item2PricePerUnit = item2Price/item2Unit/item2Size
        
        if item1DiscountType == 0{
            if let item1DiscountValue = Double(item1DiscountValue) {
                item1PricePerUnit = calculateDiscount(price: item1PricePerUnit, discountValue: item1DiscountValue)
            }
        }else if item1DiscountType == 1{
            if  let item1DiscountValue = Double(item1DiscountValue),
                let item1Get = Double(item1Get){
                item1PricePerUnit = calculateDiscountType2(price: item1PricePerUnit, buy: item1DiscountValue, get: item1Get)
            }
        }else if item1DiscountType == 2{
            if  let item1DiscountValue = Double(item1DiscountValue),
                let item1Get = Double(item1Get){
                item1PricePerUnit = calculateDiscountType3(price: item1PricePerUnit, buy: item1DiscountValue, get: item1Get)
            }
        }
        
        if item2DiscountType == 0{
            if let item2DiscountValue = Double(item2DiscountValue) {
                item2PricePerUnit = calculateDiscount(price: item2PricePerUnit, discountValue: item2DiscountValue)
            }
        }else if item2DiscountType == 1{
            if  let item2DiscountValue = Double(item2DiscountValue),
                let item2Get = Double(item2Get){
                item2PricePerUnit = calculateDiscountType2(price: item2PricePerUnit, buy: item2DiscountValue, get: item2Get)
            }
        }else if item2DiscountType == 2{
            if  let item2DiscountValue = Double(item2DiscountValue),
                let item2Get = Double(item2Get){
                item2PricePerUnit = calculateDiscountType3(price: item2PricePerUnit, buy: item2DiscountValue, get: item2Get)
            }
        }
        
        
        var cheaper = ""
        if item1PricePerUnit ≈ item2PricePerUnit{
            cheaperItem = "Item 1 and 2 have the same Price"
        }else if item1PricePerUnit < item2PricePerUnit{
            cheaper = "Item 1"
            cheaperItem = "Item 1 is cheaper"
        }else if item2PricePerUnit < item1PricePerUnit{
            cheaper = "Item 2"
            cheaperItem = "Item 2 is cheaper"
        }else{
            cheaperItem = "Item 1 and 2 have the same Price"
        }
        
//        pricePerUnitItem1 = String(item1PricePerUnit)
//        pricePerUnitItem2 = String(item2PricePerUnit)
        
        pricePerUnitItem1 = trimmingNumber(number: item1PricePerUnit)
        pricePerUnitItem2 = trimmingNumber(number: item2PricePerUnit)
        
        if item1PricePerUnit ≈ item2PricePerUnit{
            yousave = "Item 1 and 2 have the same Price"
        }else if item1PricePerUnit != item2PricePerUnit {
            let diff = trimmingNumber(number: abs(item1PricePerUnit-item2PricePerUnit))
            
//            String(format: "%.4f", abs(item1PricePerUnit-item2PricePerUnit))
            
            
            yousave = "\(cheaper) is cheaper \(diff) per (\(self.item1Unit))"
        }else{
            yousave = "Item 1 and 2 have the same Price"
        }
        
        
        
        if item1Unit != item2Unit{
            if  (self.item2Unit == "mL" || self.item2Unit == "mg") &&
                (self.item1Unit == "L" || self.item1Unit == "g"){
                item2Unit = 1/sizeUnitL(unit: self.item2Unit)
                
            }else if
                (self.item2Unit == "L" || self.item2Unit == "g") &&
                (self.item1Unit == "mL" || self.item1Unit == "mg"){
                item2Unit = 1/sizeUnitMilli(unit: self.item2Unit)
            }
            item1PricePerUnit = item1PricePerUnit/item2Unit
            item2PricePerUnit = item2PricePerUnit/item2Unit

            pricePerUnit2Item1 = String(item1PricePerUnit)
            pricePerUnit2Item2 = String(item2PricePerUnit)

            if item1PricePerUnit ≈ item2PricePerUnit{
                yousave2 = "Item 1 and 2 have the same Price"
            }else if item1PricePerUnit != item2PricePerUnit {
                let diff = trimmingNumber(number: abs(item1PricePerUnit-item2PricePerUnit))
                yousave2 = "\(cheaper) is cheaper \(diff) per (\(self.item2Unit))"
            }else{
                yousave2 = "Item 1 and 2 have the same Price"
            }
        }else{
            pricePerUnit2Item1 = ""
            pricePerUnit2Item2 = ""
            yousave2 = ""
        }
    }
    
    
    
    func trimmingNumber(number: Double) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.minimumFractionDigits = 0
        formatter.maximumFractionDigits = 8
        
        if number == Double.infinity {
            return "Infinity"
        } else if number == -Double.infinity {
            return "-Infinity"
        }
        
        guard let myString = formatter.string(from: NSDecimalNumber(decimal: Decimal(number))) else{
            return ""
        }
        
        return myString
    }
    
    func calculateDiscount(price: Double, discountValue: Double) -> Double{
        let discount = price * discountValue / 100
        return price - discount
    }
    
    func calculateDiscountType2(price: Double,buy: Double, get: Double) -> Double{
        let totalPrice = price * buy
    
        return totalPrice/get
    }
    
    func calculateDiscountType3(price: Double,buy: Double, get: Double) -> Double{
        let total = buy + get
        let discount = get / total * 100
        return calculateDiscount(price: price, discountValue: discount)
    }
    
    func sizeUnitMilli(unit: String) -> Double{
        if unit == "g" || unit == "L"{
            return 1000
        }

        return 1
    }
    
    func sizeUnitL(unit: String) -> Double{
        if unit == "mL" || unit == "mg"{
            return 1/1000
        }
        
        return 1
    }
}




struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

extension UIApplication {
    func endEditing() {
        sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}
