//
//  ItemCard.swift
//  WWDC-Davin
//
//  Created by Christophorus Davin on 17/04/23.
//

import SwiftUI
struct ItemCard: View {
    let formatter: NumberFormatter = {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.locale = Locale.current
        return formatter
    }()
    
    var name: String
    @Binding var price: String
    @Binding var size: String
    @Binding var sizeIndex: Int
    @Binding var discountType: Int
    @Binding var discountValue: String
    @Binding var get: String
    @Binding var unit: String
    
    
    let sizeOptions: [String]
    let discountTypes: [String]
    
    var body: some View {
        VStack {
            Text(name)
            TextField("Price", text: $price)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .keyboardType(.decimalPad)
               
            
            HStack{
                Picker(selection: $sizeIndex, label: Text("Size")) {
                    ForEach(0..<sizeOptions.count) { index in
                        Text(sizeOptions[index])
                    }
                }
                .onChange(of: sizeIndex, perform: { newValue in
                    unit = sizeOptions[newValue]
                })
                .pickerStyle(MenuPickerStyle())
                
                
                TextField("Amount", text: $size)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .keyboardType(.decimalPad)
            }
            
            
            
            Text("Discount Type")
            Picker(selection: $discountType, label: Text("Discount")){
                    ForEach(0..<discountTypes.count) { index in
                        Text(discountTypes[index]).font(.system(size: 8))
                    }
                }.onChange(of: discountType) { newValue in
                    discountValue = ""
                    get = ""
                }.pickerStyle(MenuPickerStyle())
            
            
            
            
            if discountType == 0 {
                TextField("Percentage", text: $discountValue)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .keyboardType(.decimalPad)
            } else {
                HStack {
                    Text("Buy")
                    TextField("X", text: $discountValue)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .keyboardType(.numberPad)
                    Text("Get")
                    TextField("Y", text: $get)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .keyboardType(.numberPad)
                }
            }
        }
        .padding(.top, 12)
        .padding(.bottom,12)
        .padding(.leading, 6)
        .padding(.trailing, 6)
        .background(RoundedRectangle(cornerRadius: 10)
            .fill(Color.white))
        
    }
    
    
}

