//
//  Helper.swift
//  WWDC-Davin
//
//  Created by Christophorus Davin on 18/04/23.
//

import Foundation
infix operator ≈: ComparisonPrecedence

func ≈ (lhs: Double, rhs: Double) -> Bool {
    let tolerance = 0.000000001
    return abs(lhs - rhs) < tolerance
}
